/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @file one_more_second.cc
  * @author Diego García Hernández alu0101633732@ull.edu.es
  * @date Oct 21 2023
  * @brief The program reads and prints an hour and adds one second to a clock time, given its hours, minutes and seconds.
  * @bug There are no known bugs
  */

#include <iostream>

int main() {
  int horas1, minutos1, segundos1;
  std::cin >> horas1;
  std::cin >> minutos1;
  std::cin >> segundos1;
  int segundos2;
  int minutos3;
  int horas3;
  if (segundos1 + 1 == 60) {
    int segundos2 = 0;
    int minutos2 = minutos1 + 1;
    if (minutos2 == 60) {
      int minuto3 = 0;
      int horas2 = horas1 + 1;
      if (horas2 == 24) {
        int horas3 = 0;
        std::cout << "00:00:00" << std::endl;
      }
      else {
        std::cout << horas2 << ":" << "00" << ":" << "00" << std::endl;
       }
  }
    else {
      std::cout << horas1 << ":" << minutos2 << ":" << "00" << std::endl;
  }
  }
  else {
    std::cout << horas1 << ":" << minutos1 << ":" << segundos1 + 1 << std::endl;
}
return 0;
}
