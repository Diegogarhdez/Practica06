/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @file integer_numbers.cc
  * @author Diego García Hernández alu0101633732@ull.edu.es
  * @date Oct 22 2023
  * @brief Write a program that reads two numbers a and b, and prints all numbers between a and b.
  * @bug There are no known bugs
  */


#include <iostream>

int main() {
  int numero1, numero2;
  std::cin >> numero1 >> numero2;

  while (numero1 <= numero2) {
    std::cout << numero1;
    if (numero1 < numero2) {
      std::cout << ",";
      }
    else {
      std::cout << std::endl;
    }
    numero1++;
  }
 return 0;
}

