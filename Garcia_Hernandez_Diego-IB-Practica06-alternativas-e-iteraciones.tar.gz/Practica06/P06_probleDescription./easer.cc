/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @file integer_division_and_reminder.cc
  * @author Albert Einstein aeinstein@ull.edu.es
  * @date Oct 12 2023
  * @brief  This program compute the day D and the month M of the Easter Sunday of every given year Y. 
  * @bug There are no known bugs
  */

#include <iostream>

int main() {
  int Y;
  std::cin >> Y;
  double k =(Y % 100);
  double x =(Y % 19);
  double b =(Y % 4);
  double c =(Y % 7);
  double q =(k / 4);
  double p =((13 + 8 * k ) / 25);
  double y =((15 − p + k − q) % 30);
  double z =((19 * x + y ) % 30);
  double n =((4 + k − q)  %  7);
  double e =((2 * b + 4 * c + 6 * z + n) % 7); 
  std::cout << e << std::endl;
return 0;
}
