/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @file harmonic_numbers.cc
  * @author Diego García Hernández alu0101633732@ull.edu.es
  * @date Oct 22 2023
  * @brief This is a program that reads a number n and prints the n-th harmonic number, defined as Hn = 1/1 + 1/2 + ⋯ + 1/n.
  * @bug There are no known bugs
  */

#include <iostream>
#include <iomanip>

int main() {
  int numero;
  double harmonic = 0.0;

  std::cin >> numero;

  for (int i = 1; i <= numero; i++) {
      harmonic += 1.0 / i;
  }
  std::cout << std::fixed << std::setprecision(4) << harmonic << std::endl;
  return 0;
}

