/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @file maximun.cc
  * @author Diego García Hernández alu0101633732@ull.edu.es
  * @date Oct 21 2023
  * @brief The program reads three numbers and prints the maximun number. 
  * @bug There are no known bugs
  */

#include <iostream>

int main() {
  int numero1, numero2, numero3;
  std::cin >> numero1;
  std::cin >> numero2;
  std::cin >> numero3;
  if (numero3 > numero2 & numero3 > numero1 ) {
       std::cout << numero3 << std::endl;
    }
  else if ( numero2 > numero1 ) {
    std::cout << numero2 << std::endl;
  }
  else {
  std::cout << numero1 << std::endl;  
  }
  return 0;
}
