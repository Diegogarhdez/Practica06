/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @file up_low_case.cc
  * @author Diego Gracía Hernández alu0101633732@ull.edu.es
  * @date Oct 20 2023
  * @brief The program reads two letters and prints a inverse. 
  * @bug There are no known bugs
  */

#include <iostream>

int main() {

  char letra1;
  std::cin >> letra1;
  int ascii1 = static_cast<int>(letra1);
  char letra2;
  if (ascii1 < 91) {
  letra2 = static_cast<char>(ascii1 + 32);
}
  else {
  letra2 = static_cast<int>(ascii1 - 32);
}
  std::cout << letra2 << std::endl;
return 0;
}
